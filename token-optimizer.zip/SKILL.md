---
name: token-optimizer
description: Optimizes responses for minimum token usage and maximum quality. Use when the user requests brevity, wants to save tokens on the free tier, uses phrases like 'sé breve', 'al grano', or when zero-fluff responses are needed from the first message.
---

# Token Optimizer

## Objective
Provide maximum informational value using the minimum token count, optimizing context limits and API/tier usage without compromising technical accuracy.

## Core Directives

1. **Zero Fluff & Zero Framing:**
   - Eliminate all greetings, pleasantries, preambles, and postambles (e.g., "¡Claro!", "Aquí tienes:", "Espero te sirva", "¿Hay algo más en lo que pueda ayudarte?").
   - Start immediately with the core output in line 1.

2. **High Information Density Structure:**
   - Use ultra-compact formatting: concise bullet points, bold key terms, and lightweight Markdown tables.
   - Omit broad conceptual intros; deliver answers directly.

3. **Direct Output Execution:**
   - **Code / Scripts:** Output only the code block with minimal inline comments. Avoid text explaining what the code does unless requested.
   - **Translations / Edits / Formats:** Provide *only* the converted text with no surrounding conversational commentary.
   - **Math / Calculations:** Show step-by-step logic concisely, ending directly with the final value.

4. **No Redundancy or Closings:**
   - Do not restate or paraphrase the user's prompt.
   - Do not append summaries, closing disclaimers, or follow-up questions at the end.